*********************************************************************
*  Name      :  Mohan Kancherla & Veena Saraswathy        
*  Student ID:  109421260 , 108559009               
*  Class     :  CSC 2421           
*  Due Date  :  May 01,2019
*********************************************************************


	                       Read Me


*********************************************************************
*  Description of the program
*********************************************************************

The program  is for the data analysis for academy awards. It will contains information
about the awardee of the movie, category, information about year, gere, duration, synposis etc..

It will search for record fully and partially, add , delete , modify and sort the reports
and save into new file.

*********************************************************************
*  Source files
*********************************************************************

Name:  main.cpp
   Main program. This is the driver program that calls sub-functions
   to read data from an user, use the data to manipulate the database, 
   and display the results.

Name:  BinarySearchTree.h
   Contains the definition for the class BinarySearchTree.  

Name:  BianrySeachTree.hpp
   Implementation of BinarySearchTree class for the program. This class 
   provide the functions to intialize the data from *.csv file into
   a binary search tree and also helps in manipulation like, deleting
   of a node, freeing the memory, printing the tree if necessary. 

Name:  DataFunctions.h
   Contains the definition for the DataFunctions class.

Name:  DataFunctions.hpp
   This class is implemented to do the operations that you can see on
   the menu which are adding, deleting, modifying, searching, sorting
   and saving all the modified data into a *.csv file.

Name:  Node.h
   Contains the definition for the Node class. We are using structures for award data and pictures data.
   This class is used to create a node for the BinarySearchTree class.


********************************************************************
*  Work done by Team Members
********************************************************************
   
Mohan Kancherla(109421260)

	-  Reading data from CSV file from Actor-Actress database and storing into binary tree
	-  Adding the record
	-  Delete the record
	-  Modify the record
	-  Sort the report by year 
	-  Displaying the Main Menu
	-  Testing the output

Veena Saraswathy(108559009)

	-  Reading data from CSV file from Pictures database and storing into binary tree
	-  Search
	-  Partial Search
	-  Sort the report by film
	-  Final report of the project
	-  Testing the output

********************************************************************
*  Status of program
********************************************************************

   The program runs successfully.  
   
   The program was developed and tested on Visual studios 2017. It was 
   compiled, run, and tested on csegrid.ucdenver.pvt.

